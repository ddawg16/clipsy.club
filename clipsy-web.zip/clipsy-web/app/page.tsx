import { CampaignHub } from '@/components/CampaignHub';
import {
  Differentiators,
  FinalCta,
  Footer,
  Hero,
  LearnAndFaq,
  LiveBoard,
  Nav,
  WireAndSteps,
} from '@/components/Sections';
import { getCampaigns, getCounts, getWire } from '@/lib/data';
import { safeExternal } from '@/lib/safe';

// Revalidate every 5 minutes — the ingest job runs every 15, so this is fresh
// enough without hammering the database on every visit.
export const revalidate = 300;

export default async function HomePage() {
  const [campaigns, wire, counts] = await Promise.all([getCampaigns('hot', 50), getWire(6), getCounts()]);
  const discord = safeExternal(process.env.NEXT_PUBLIC_DISCORD_INVITE, '#');

  return (
    <>
      <Nav discord={discord} />
      <main>
        <Hero discord={discord} liveCount={counts.campaigns} sourceCount={counts.sources} />
        <LiveBoard campaigns={campaigns} />
        <CampaignHub campaigns={campaigns} />
        <WireAndSteps events={wire} />
        <Differentiators />
        <LearnAndFaq />
        <FinalCta discord={discord} />
      </main>
      <Footer discord={discord} />
    </>
  );
}
