import type { Campaign, WireEvent } from '@/lib/types';
import { ago, rate, timeLeft, views } from '@/lib/format';
import { safeHref } from '@/lib/safe';
import { ArrowRight, ClockIcon, DiscordIcon, Logo } from './Logo';

/* ------------------------------------------------------------------ nav */

export function Nav({ discord }: { discord: string }) {
  return (
    <div
      style={{
        position: 'sticky',
        top: 0,
        zIndex: 20,
        background: 'rgba(250,241,216,0.92)',
        backdropFilter: 'blur(8px)',
        borderBottom: '1px solid var(--cream-line)',
      }}
    >
      <div className="wrap" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 76, gap: 24 }}>
        <a href="/" style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <Logo size={36} />
          <span className="display" style={{ fontSize: 21, fontWeight: 700 }}>
            Clipsy
          </span>
        </a>
        <nav style={{ display: 'flex', alignItems: 'center', gap: 28, fontSize: 14.5, fontWeight: 500 }}>
          <a href="#board">Campaigns</a>
          <a href="#hub">Hub</a>
          <a href="#wire">The Wire</a>
          <a href="#learn">Learn</a>
        </nav>
        <a className="btn btn-primary" href={discord} target="_blank" rel="noopener noreferrer" style={{ padding: '11px 18px', fontSize: 14 }}>
          Join the Discord
        </a>
      </div>
    </div>
  );
}

/* ----------------------------------------------------------------- hero */

export function Hero({
  discord,
  liveCount,
  sourceCount,
}: {
  discord: string;
  liveCount: number;
  sourceCount: number;
}) {
  return (
    <div className="wrap" style={{ paddingTop: 88, paddingBottom: 64 }}>
      <div style={{ display: 'flex', gap: 64, alignItems: 'flex-start', flexWrap: 'wrap' }}>
        <div style={{ flex: '1 1 420px', display: 'flex', flexDirection: 'column', gap: 26, minWidth: 0 }}>
          <span className="pill pill-neutral" style={{ alignSelf: 'flex-start' }}>
            <span className="dot" />
            {liveCount > 0
              ? `${liveCount} campaigns live right now, across ${sourceCount} networks`
              : 'Indexing campaigns from every network we can reach'}
          </span>

          <h1 style={{ fontSize: 'clamp(38px, 6vw, 60px)', lineHeight: 1.02, fontWeight: 700, maxWidth: 640 }}>
            Everything clipping,
            <br />
            in one place.
          </h1>

          <p style={{ fontSize: 18, lineHeight: 1.55, color: 'var(--ink-soft)', maxWidth: 520, margin: 0 }}>
            We don&rsquo;t run one clipping program — we watch all of them. Campaigns from across the networks where
            clippers actually get paid, human-reviewed and dropped into one feed. No more five tabs open.
          </p>

          <div style={{ display: 'flex', gap: 14, alignItems: 'center', flexWrap: 'wrap' }}>
            <a className="btn btn-primary" href={discord} target="_blank" rel="noopener noreferrer" style={{ padding: '15px 26px', fontSize: 16 }}>
              Join the Discord
              <ArrowRight />
            </a>
            <a className="btn btn-ghost" href="#hub" style={{ padding: '15px 24px', fontSize: 16 }}>
              See what&rsquo;s worth clipping
            </a>
          </div>

          <p style={{ fontSize: 13.5, color: 'var(--ink-faint)', margin: 0 }}>
            Free to join. No follower minimum. We&rsquo;ll tell you when a campaign isn&rsquo;t worth your time.
          </p>
        </div>

        <StatsPanel liveCount={liveCount} sourceCount={sourceCount} />
      </div>
    </div>
  );
}

/**
 * The three headline figures are TOTALS ACROSS THE NETWORKS WE INDEX, not
 * Clipsy's own payouts. The label says so explicitly — see the note in the
 * handover about why that wording is not optional.
 */
function StatsPanel({ liveCount, sourceCount }: { liveCount: number; sourceCount: number }) {
  const stats = [
    { value: '$60M+', label: 'paid out across these networks' },
    { value: '77,000+', label: 'clippers active on them' },
    { value: '200+', label: 'campaigns run through them' },
    { value: String(sourceCount || '—'), label: 'networks we pull from', accent: true },
  ];

  return (
    <div className="card" style={{ flex: '1 1 340px', padding: 28, display: 'flex', flexDirection: 'column', gap: 22, minWidth: 0 }}>
      <span className="eyebrow">Across the networks we track</span>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0,1fr))', gap: 22 }}>
        {stats.map((s) => (
          <div key={s.label} style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <span className="display tabular" style={{ fontSize: 34, fontWeight: 700, color: s.accent ? 'var(--accent)' : undefined }}>
              {s.value}
            </span>
            <span style={{ fontSize: 13, color: 'var(--ink-soft)' }}>{s.label}</span>
          </div>
        ))}
      </div>
      <div style={{ height: 1, background: 'var(--cream-line)' }} />
      <p style={{ fontSize: 12, color: 'var(--ink-faint)', margin: 0, lineHeight: 1.5 }}>
        Industry totals published by the platforms we index — not Clipsy&rsquo;s own payouts. We&rsquo;ll show our own
        numbers here once they mean something.
      </p>
      <div>
        <span className="eyebrow" style={{ fontSize: 11.5, display: 'block', marginBottom: 10 }}>
          Currently live: {liveCount} campaigns
        </span>
      </div>
    </div>
  );
}

/* ----------------------------------------------------------- live board */

export function LiveBoard({ campaigns }: { campaigns: Campaign[] }) {
  const featured = campaigns.slice(0, 3);

  return (
    <div
      id="board"
      className="section"
      style={{ background: 'var(--cream-card)', borderTop: '1px solid var(--cream-line)', borderBottom: '1px solid var(--cream-line)' }}
    >
      <div className="wrap" style={{ display: 'flex', flexDirection: 'column', gap: 36 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, maxWidth: 560 }}>
          <span className="eyebrow">The live board</span>
          <h2 style={{ fontSize: 34, fontWeight: 700 }}>Every open campaign. Every network. One board.</h2>
          <p style={{ fontSize: 15.5, color: 'var(--ink-soft)', margin: 0, lineHeight: 1.5 }}>
            Each card is tagged with where it actually lives. A human on our side reviews it before it&rsquo;s allowed on
            the board — bots don&rsquo;t get a vote.
          </p>
        </div>

        {featured.length === 0 ? (
          <div className="card">
            <p className="empty">
              Nothing on the board yet. This fills automatically the first time the ingest job runs against a live
              network.
            </p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 20 }}>
            {featured.map((c) => {
              const href = safeHref(c.url);
              return (
                <div key={c.id} className="card" style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 16 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
                    <span className="pill pill-neutral">{c.source}</span>
                    <span className="pill pill-active">
                      <span className="dot" />
                      Active
                    </span>
                  </div>
                  <div>
                    <div className="display" style={{ fontWeight: 700, fontSize: 17 }}>
                      {c.name}
                    </div>
                    <div style={{ fontSize: 13, color: 'var(--ink-faint)', marginTop: 2 }}>{views(c.minViews)}</div>
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      paddingTop: 8,
                      borderTop: '1px solid var(--cream-line)',
                    }}
                  >
                    <span className="display tabular" style={{ fontSize: 20, fontWeight: 700 }}>
                      {rate(c.rateCpm)}
                      <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--ink-soft)' }}>/100k</span>
                    </span>
                    <span style={{ fontSize: 12.5, color: 'var(--ink-faint)', display: 'flex', alignItems: 'center', gap: 5 }}>
                      <ClockIcon />
                      {timeLeft(c.endsAt)}
                    </span>
                  </div>
                  {href && (
                    <a className="btn btn-ghost" href={href} target="_blank" rel="noopener noreferrer nofollow" style={{ fontSize: 14 }}>
                      Open on {c.source}
                    </a>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------ wire + how it works */

const STEPS = [
  { n: '01', title: 'Join', body: 'Pick campaigns from any network on the board. One login, no matter where the campaign actually lives.' },
  { n: '02', title: 'Claim', body: 'A human reviews your claim and puts you on the roster — not a bot approving anyone into a rate that is about to get cut.' },
  { n: '03', title: 'Post', body: 'Clip it, post it, get paid on that network&rsquo;s own schedule. We just make sure you knew it was there.' },
];

export function WireAndSteps({ events }: { events: WireEvent[] }) {
  return (
    <div id="wire" className="wrap section" style={{ display: 'flex', gap: 56, alignItems: 'flex-start', flexWrap: 'wrap' }}>
      <div style={{ flex: '1 1 380px', display: 'flex', flexDirection: 'column', gap: 18, minWidth: 0 }}>
        <span className="eyebrow">The Wire</span>
        <h2 style={{ fontSize: 30, fontWeight: 700, maxWidth: 420 }}>
          Nobody tells you when a network quietly cuts rates. We do.
        </h2>
        <p style={{ fontSize: 15, color: 'var(--ink-soft)', margin: 0, maxWidth: 420, lineHeight: 1.5 }}>
          A running log of rate moves, new drops, and payout problems across every network we track — updated the same
          day it happens.
        </p>

        <div style={{ background: 'var(--ink)', borderRadius: 16, padding: 22, display: 'flex', flexDirection: 'column', marginTop: 8 }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              paddingBottom: 14,
              marginBottom: 6,
              borderBottom: '1px solid rgba(255,255,255,0.12)',
            }}
          >
            <span className="dot" />
            <span
              className="display"
              style={{ fontSize: 12.5, fontWeight: 600, color: '#F2ECD9', letterSpacing: '0.03em', textTransform: 'uppercase' }}
            >
              Live feed
            </span>
          </div>

          {events.length === 0 ? (
            <p style={{ color: 'rgba(242,236,217,0.55)', fontSize: 13.5, lineHeight: 1.5, margin: '12px 0' }}>
              The Wire starts the moment ingest runs twice — it reports the difference between one run and the next, so
              there is nothing honest to show until then.
            </p>
          ) : (
            events.map((e, i) => (
              <div
                key={e.id}
                style={{
                  display: 'flex',
                  gap: 14,
                  padding: '11px 0',
                  borderBottom: i === events.length - 1 ? 'none' : '1px solid rgba(255,255,255,0.08)',
                }}
              >
                <span
                  className="display"
                  style={{ fontSize: 12, color: 'rgba(242,236,217,0.5)', flexShrink: 0, paddingTop: 1, minWidth: 62 }}
                >
                  {ago(e.created_at)}
                </span>
                <span
                  style={{
                    fontSize: 13.5,
                    lineHeight: 1.4,
                    color: e.severity === 'good' ? 'var(--accent)' : '#F2ECD9',
                  }}
                >
                  {e.headline}
                </span>
              </div>
            ))
          )}
        </div>
      </div>

      <div style={{ flex: '1 1 380px', display: 'flex', flexDirection: 'column', gap: 18, minWidth: 0 }}>
        <span className="eyebrow">How it works</span>
        <h2 style={{ fontSize: 30, fontWeight: 700 }}>Three steps. Not five.</h2>
        <p style={{ fontSize: 15, color: 'var(--ink-soft)', margin: '0 0 6px', lineHeight: 1.5 }}>
          We didn&rsquo;t need to make it complicated to make it look serious.
        </p>

        <div>
          {STEPS.map((s, i) => (
            <div
              key={s.n}
              style={{
                display: 'flex',
                gap: 18,
                padding: '20px 0',
                borderBottom: i === STEPS.length - 1 ? 'none' : '1px solid var(--cream-line)',
              }}
            >
              <span className="display" style={{ fontSize: 22, fontWeight: 700, color: 'var(--accent)', width: 32, flexShrink: 0 }}>
                {s.n}
              </span>
              <div>
                <div style={{ fontWeight: 600, fontSize: 16, marginBottom: 4 }}>{s.title}</div>
                <div style={{ fontSize: 14, color: 'var(--ink-soft)', lineHeight: 1.5 }}>
                  {s.title === 'Post'
                    ? "Clip it, post it, get paid on that network's own schedule. We just make sure you knew it was there."
                    : s.body}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------- differentiators */

const DIFFS = [
  { title: 'One dashboard, every network', body: 'No more tab-switching between a dozen platforms and server DMs.' },
  { title: 'A human reviews every claim', body: 'Not a bot waving everyone into a campaign that is about to get its rate cut.' },
  { title: 'Dedicated team rosters', body: 'A team captain who knows your numbers — not a support ticket queue.' },
  { title: 'We flag rate moves same-day', body: 'The Wire catches cuts, delays, and new drops before you find out the hard way.' },
];

export function Differentiators() {
  return (
    <div id="brands" className="section" style={{ background: 'var(--ink)' }}>
      <div className="wrap" style={{ display: 'flex', flexDirection: 'column', gap: 44 }}>
        <div style={{ maxWidth: 560, display: 'flex', flexDirection: 'column', gap: 12 }}>
          <span className="eyebrow" style={{ color: 'rgba(242,236,217,0.55)' }}>
            Why clip through us
          </span>
          <h2 style={{ fontSize: 32, fontWeight: 700, color: 'var(--cream)' }}>
            Short answer: you don&rsquo;t have to pick one network anymore.
          </h2>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(230px, 1fr))', gap: 18 }}>
          {DIFFS.map((d) => (
            <div
              key={d.title}
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: 12,
                padding: 22,
                borderRadius: 14,
                background: 'rgba(250,241,216,0.05)',
                border: '1px solid rgba(250,241,216,0.12)',
              }}
            >
              <div style={{ fontWeight: 600, fontSize: 15, color: 'var(--cream)' }}>{d.title}</div>
              <div style={{ fontSize: 13.5, color: 'rgba(242,236,217,0.6)', lineHeight: 1.5 }}>{d.body}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------ learn + faq */

const GUIDES = [
  'Your first 48 hours on a roster',
  'Reading a rate card without getting burned',
  'Why clips get rejected, and how to stop it',
  'Editing for retention, not just length',
  'Picking the right network for your niche',
  'Getting noticed by a team captain',
];

const FAQ = [
  { q: 'Do I need a big following?', a: 'No — never have. Campaigns care about clip performance, not your follower count.' },
  {
    q: 'What do I actually need to start?',
    a: 'A laptop for editing — phone-only will not keep up with the faster campaigns — and an account on whichever network a campaign runs on. We will tell you which.',
  },
  { q: 'Is this free to join?', a: 'Yes. Always free to browse the board and join the Discord.' },
];

export function LearnAndFaq() {
  return (
    <>
      <div id="learn" className="wrap section" style={{ display: 'flex', flexDirection: 'column', gap: 36 }}>
        <div style={{ maxWidth: 560, display: 'flex', flexDirection: 'column', gap: 12 }}>
          <span className="eyebrow">Learn to clip</span>
          <h2 style={{ fontSize: 32, fontWeight: 700 }}>Nobody is born knowing this.</h2>
          <p style={{ fontSize: 15.5, color: 'var(--ink-soft)', margin: 0, lineHeight: 1.5 }}>
            Six guides that take you from your first claim to actually getting picked for the good rosters.
          </p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 18 }}>
          {GUIDES.map((g, i) => (
            <div key={g} className="card" style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 8 }}>
              <span className="eyebrow" style={{ fontSize: 11, color: 'var(--ink-faint)' }}>
                Guide {String(i + 1).padStart(2, '0')}
              </span>
              <span style={{ fontWeight: 600, fontSize: 15.5, lineHeight: 1.35 }}>{g}</span>
            </div>
          ))}
        </div>
      </div>

      <div
        className="section"
        style={{ background: 'var(--cream-card)', borderTop: '1px solid var(--cream-line)', borderBottom: '1px solid var(--cream-line)' }}
      >
        <div className="wrap" style={{ display: 'flex', gap: 64, flexWrap: 'wrap' }}>
          <div style={{ flex: '1 1 300px', display: 'flex', flexDirection: 'column', gap: 14 }}>
            <span className="eyebrow">Before you join</span>
            <h2 style={{ fontSize: 30, fontWeight: 700, maxWidth: 340 }}>
              We&rsquo;d rather lose you here than have you waste a week.
            </h2>
          </div>
          <div style={{ flex: '1 1 420px' }}>
            {FAQ.map((f, i) => (
              <div key={f.q} style={{ padding: '20px 0', borderBottom: i === FAQ.length - 1 ? 'none' : '1px solid var(--cream-line)' }}>
                <div style={{ fontWeight: 600, fontSize: 16, marginBottom: 6 }}>{f.q}</div>
                <div style={{ fontSize: 14.5, color: 'var(--ink-soft)', lineHeight: 1.5 }}>{f.a}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

/* -------------------------------------------------------- cta + footer */

export function FinalCta({ discord }: { discord: string }) {
  return (
    <div className="wrap section" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', gap: 22 }}>
      <h2 style={{ fontSize: 36, fontWeight: 700, maxWidth: 560 }}>
        Every network is already live. You&rsquo;re just not in the feed yet.
      </h2>
      <a className="btn btn-primary" href={discord} target="_blank" rel="noopener noreferrer" style={{ padding: '16px 28px', fontSize: 16 }}>
        <DiscordIcon />
        Join the Discord
      </a>
    </div>
  );
}

export function Footer({ discord }: { discord: string }) {
  return (
    <footer style={{ borderTop: '1px solid var(--cream-line)', padding: '56px 0 40px' }}>
      <div className="wrap" style={{ display: 'flex', justifyContent: 'space-between', gap: 40, flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14, maxWidth: 260 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <Logo size={30} />
            <span className="display" style={{ fontSize: 17, fontWeight: 700 }}>
              Clipsy
            </span>
          </div>
          <p style={{ fontSize: 13, color: 'var(--ink-faint)', lineHeight: 1.5, margin: 0 }}>
            Every clipping network, one board. Built and moderated by clippers.
          </p>
        </div>

        <div style={{ display: 'flex', gap: 64, flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <span className="eyebrow" style={{ fontSize: 11.5 }}>
              Product
            </span>
            <a href="#board" style={{ fontSize: 14, color: 'var(--ink-soft)' }}>Campaigns</a>
            <a href="#hub" style={{ fontSize: 14, color: 'var(--ink-soft)' }}>Campaign hub</a>
            <a href="#wire" style={{ fontSize: 14, color: 'var(--ink-soft)' }}>The Wire</a>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <span className="eyebrow" style={{ fontSize: 11.5 }}>
              Community
            </span>
            <a href={discord} target="_blank" rel="noopener noreferrer" style={{ fontSize: 14, color: 'var(--ink-soft)' }}>
              Discord
            </a>
          </div>
        </div>
      </div>

      <div className="wrap" style={{ marginTop: 40, paddingTop: 24, borderTop: '1px solid var(--cream-line)' }}>
        <span style={{ fontSize: 12.5, color: 'var(--ink-faint)' }}>
          © Clipsy Club. Independent — not affiliated with the networks we index. Every campaign links back to its
          source.
        </span>
      </div>
    </footer>
  );
}
