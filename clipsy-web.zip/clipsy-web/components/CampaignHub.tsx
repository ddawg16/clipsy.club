'use client';

import { useMemo, useState } from 'react';
import type { Campaign, SortKey } from '@/lib/types';
import { payout, rate, views } from '@/lib/format';
import { safeHref } from '@/lib/safe';

const TABS: Array<{ id: SortKey; label: string; note: string }> = [
  {
    id: 'hot',
    label: 'Hottest',
    note: 'Ranked by clips posted, views landed, and how fast the pool is filling over the last 48 hours. Hot means competitive — get in early or not at all.',
  },
  {
    id: 'easy',
    label: 'Easiest to get paid',
    note: 'Ranked by low view minimums, fast payout cycles, and how rarely clips get rejected. Best place to start if you have never been paid for a clip.',
  },
  {
    id: 'rate',
    label: 'Best rate',
    note: 'Straight CPM, highest first. Worth saying out loud: the highest rate is almost never the easiest money.',
  },
  {
    id: 'ending',
    label: 'Ending soon',
    note: 'Closing soonest. These pools cap out early more often than they run to the deadline.',
  },
];

const EFFORT_STYLE: Record<string, { background: string; color: string }> = {
  Low: { background: 'rgba(79,154,104,0.20)', color: 'var(--green-ink)' },
  Medium: { background: 'var(--amber-bg)', color: 'var(--amber-ink)' },
  High: { background: 'var(--red-bg)', color: 'var(--red-ink)' },
};

const GRID = '44px minmax(0,1fr) 84px 132px 96px 92px 104px';

function sortCampaigns(list: Campaign[], key: SortKey): Campaign[] {
  const copy = [...list];
  switch (key) {
    case 'easy':
      return copy.sort((a, b) => b.effortScore - a.effortScore);
    case 'rate':
      return copy.sort((a, b) => (b.rateCpm ?? -1) - (a.rateCpm ?? -1));
    case 'ending':
      return copy.sort((a, b) => {
        const at = a.endsAt ? new Date(a.endsAt).getTime() : Infinity;
        const bt = b.endsAt ? new Date(b.endsAt).getTime() : Infinity;
        return at - bt;
      });
    default:
      return copy.sort((a, b) => b.heat - a.heat);
  }
}

export function CampaignHub({ campaigns }: { campaigns: Campaign[] }) {
  const [sort, setSort] = useState<SortKey>('hot');
  const rows = useMemo(() => sortCampaigns(campaigns, sort), [campaigns, sort]);
  const active = TABS.find((t) => t.id === sort) ?? TABS[0];

  return (
    <div id="hub" className="wrap section" style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24, flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, maxWidth: 560 }}>
          <span className="eyebrow">Campaign hub</span>
          <h2 style={{ fontSize: 34, fontWeight: 700 }}>Not every campaign is worth your night.</h2>
          <p style={{ fontSize: 15.5, color: 'var(--ink-soft)', margin: 0, lineHeight: 1.5 }}>
            The board shows you what&rsquo;s open. The hub tells you which ones are actually running hot — and which
            ones will actually pay you without a fight.
          </p>
        </div>
        <span className="pill pill-neutral">
          <span className="dot" />
          Re-ranked every 15 minutes
        </span>
      </div>

      <div role="tablist" aria-label="Sort campaigns" style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        {TABS.map((tab) => {
          const on = tab.id === sort;
          return (
            <button
              key={tab.id}
              role="tab"
              aria-selected={on}
              onClick={() => setSort(tab.id)}
              style={{
                padding: '10px 18px',
                borderRadius: 999,
                fontFamily: 'var(--font-display), sans-serif',
                fontWeight: 600,
                fontSize: 14,
                cursor: 'pointer',
                minHeight: 44,
                border: `1.5px solid ${on ? 'var(--ink)' : 'var(--cream-line)'}`,
                background: on ? 'var(--ink)' : 'transparent',
                color: on ? 'var(--cream)' : 'var(--ink-soft)',
              }}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      <p style={{ fontSize: 13.5, color: 'var(--ink-faint)', margin: 0, maxWidth: 640, lineHeight: 1.5 }}>
        {active.note}
      </p>

      <div className="card" style={{ overflow: 'hidden' }}>
        <div className="scroll-x">
          <div style={{ minWidth: 860 }}>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: GRID,
                gap: 16,
                alignItems: 'center',
                padding: '14px 22px',
                background: 'var(--cream)',
                borderBottom: '1px solid var(--cream-line)',
              }}
            >
              {['#', 'Campaign', 'Rate', 'Heat', 'Effort', 'Payout', ''].map((h, i) => (
                <span key={i} className="eyebrow" style={{ fontSize: 11 }}>
                  {h}
                </span>
              ))}
            </div>

            {rows.length === 0 ? (
              <p className="empty">
                No live campaigns yet. The board fills the first time the ingest job runs — until then this is honestly
                empty rather than padded with placeholders.
              </p>
            ) : (
              rows.map((c, i) => {
                const href = safeHref(c.url);
                return (
                  <div
                    key={c.id}
                    style={{
                      display: 'grid',
                      gridTemplateColumns: GRID,
                      gap: 16,
                      alignItems: 'center',
                      padding: '16px 22px',
                      borderBottom: '1px solid var(--cream-line)',
                    }}
                  >
                    <span className="display tabular" style={{ fontSize: 15, fontWeight: 700, color: 'var(--ink-faint)' }}>
                      {String(i + 1).padStart(2, '0')}
                    </span>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: 5, minWidth: 0 }}>
                      <span style={{ fontWeight: 600, fontSize: 15 }}>{c.name}</span>
                      <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                        <span className="pill pill-neutral" style={{ fontSize: 11.5, padding: '3px 9px' }}>
                          {c.source}
                        </span>
                        <span style={{ fontSize: 12, color: 'var(--ink-faint)' }}>{views(c.minViews)}</span>
                      </div>
                    </div>

                    <span className="display tabular" style={{ fontSize: 17, fontWeight: 700 }}>
                      {rate(c.rateCpm)}
                      <span style={{ fontSize: 11, fontWeight: 500, color: 'var(--ink-soft)' }}>/100k</span>
                    </span>

                    <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                      <div
                        style={{ flex: 1, height: 6, borderRadius: 999, background: 'var(--cream-line)', overflow: 'hidden' }}
                        role="img"
                        aria-label={`Heat ${c.heat} out of 100`}
                      >
                        <div style={{ height: '100%', width: `${Math.max(0, Math.min(100, c.heat))}%`, background: 'var(--accent)', borderRadius: 999 }} />
                      </div>
                      <span className="tabular" style={{ fontSize: 12, color: 'var(--ink-faint)', fontFamily: 'var(--font-display), sans-serif' }}>
                        {c.heat}
                      </span>
                    </div>

                    <span className="pill" style={{ ...EFFORT_STYLE[c.effort], fontSize: 12 }}>
                      {c.effort}
                    </span>

                    <span style={{ fontSize: 13, color: 'var(--ink-soft)' }}>{payout(c.payoutDays)}</span>

                    {href ? (
                      <a
                        className="btn btn-primary"
                        href={href}
                        target="_blank"
                        rel="noopener noreferrer nofollow"
                        style={{ padding: '9px 14px', fontSize: 13.5 }}
                      >
                        Claim
                      </a>
                    ) : (
                      <span style={{ fontSize: 13, color: 'var(--ink-faint)' }}>No link</span>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        <div
          style={{
            padding: '16px 22px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: 16,
            flexWrap: 'wrap',
            background: 'var(--cream)',
          }}
        >
          <span style={{ fontSize: 13, color: 'var(--ink-faint)', maxWidth: '60ch' }}>
            Heat is our own score — clips posted, views landed, and how fast the pool is filling. Effort is how hard it
            is to actually get approved and paid.
          </span>
        </div>
      </div>
    </div>
  );
}
