export interface Campaign {
  id: string;
  name: string;
  source: string;
  url: string | null;
  rateCpm: number | null;
  minViews: number | null;
  platforms: string[];
  endsAt: string | null;
  heat: number;
  effort: 'Low' | 'Medium' | 'High';
  effortScore: number;
  payoutDays: number | null;
}

export interface WireEvent {
  id: number;
  type: string;
  headline: string;
  severity: 'info' | 'good' | 'warn';
  created_at: string;
}

export type SortKey = 'hot' | 'easy' | 'rate' | 'ending';
