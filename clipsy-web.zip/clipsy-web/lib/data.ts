import { createClient } from '@supabase/supabase-js';
import type { Campaign, SortKey, WireEvent } from './types';

/**
 * Reads run through the ANON key, which is safe to ship because Row Level
 * Security decides what it can see (clipsy-engine/sql/002_security.sql).
 * The service-role key must never appear in this app.
 */
function client() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return null;
  return createClient(url, key, { auth: { persistSession: false } });
}

const ORDER: Record<SortKey, { column: string; ascending: boolean }> = {
  hot: { column: 'heat', ascending: false },
  easy: { column: 'effort_score', ascending: false },
  rate: { column: 'rate_cpm', ascending: false },
  ending: { column: 'ends_at', ascending: true },
};

type Row = {
  id: string;
  name: string;
  source_id: string;
  url: string | null;
  rate_cpm: number | null;
  min_views: number | null;
  platforms: string[] | null;
  ends_at: string | null;
  heat: number;
  effort_label: string;
  effort_score: number;
  payout_days: number | null;
  sources: { name: string } | { name: string }[] | null;
};

function toCampaign(r: Row): Campaign {
  const src = Array.isArray(r.sources) ? r.sources[0] : r.sources;
  const label = r.effort_label === 'Low' || r.effort_label === 'High' ? r.effort_label : 'Medium';
  return {
    id: r.id,
    name: r.name,
    source: src?.name ?? r.source_id,
    url: r.url,
    rateCpm: r.rate_cpm,
    minViews: r.min_views,
    platforms: r.platforms ?? [],
    endsAt: r.ends_at,
    heat: r.heat ?? 0,
    effort: label,
    effortScore: r.effort_score ?? 50,
    payoutDays: r.payout_days,
  };
}

const SELECT =
  'id, name, source_id, url, rate_cpm, min_views, platforms, ends_at, heat, effort_label, effort_score, payout_days, sources(name)';

/**
 * Every fetch degrades to an empty array rather than throwing. Before the first
 * successful ingest the database IS empty, and a homepage that 500s because a
 * campaign table has no rows is worse than one that says "nothing live yet".
 */
export async function getCampaigns(sort: SortKey = 'hot', limit = 50): Promise<Campaign[]> {
  const db = client();
  if (!db) return [];
  const o = ORDER[sort] ?? ORDER.hot;

  const { data, error } = await db
    .from('campaigns')
    .select(SELECT)
    .eq('status', 'active')
    .order(o.column, { ascending: o.ascending, nullsFirst: false })
    .limit(limit);

  if (error || !data) return [];
  return (data as unknown as Row[]).map(toCampaign);
}

export async function getWire(limit = 6): Promise<WireEvent[]> {
  const db = client();
  if (!db) return [];

  const { data, error } = await db
    .from('wire_events')
    .select('id, type, headline, severity, created_at')
    .eq('published', true)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error || !data) return [];
  return data as WireEvent[];
}

export async function getCounts(): Promise<{ campaigns: number; sources: number }> {
  const db = client();
  if (!db) return { campaigns: 0, sources: 0 };

  const [campaigns, sources] = await Promise.all([
    db.from('campaigns').select('id', { count: 'exact', head: true }).eq('status', 'active'),
    db.from('sources').select('id', { count: 'exact', head: true }).eq('enabled', true),
  ]);

  return { campaigns: campaigns.count ?? 0, sources: sources.count ?? 0 };
}
