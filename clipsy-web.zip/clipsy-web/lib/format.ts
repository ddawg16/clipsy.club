export function rate(value: number | null): string {
  return value == null ? '—' : `$${value % 1 === 0 ? value : value.toFixed(2)}`;
}

export function views(value: number | null): string {
  if (value == null) return 'No view minimum';
  return `${new Intl.NumberFormat('en-US').format(value)} views to qualify`;
}

export function timeLeft(endsAt: string | null): string {
  if (!endsAt) return 'No deadline';
  const ms = new Date(endsAt).getTime() - Date.now();
  if (Number.isNaN(ms)) return 'No deadline';
  if (ms <= 0) return 'Closed';

  const hours = Math.floor(ms / 3_600_000);
  if (hours < 24) return `${hours}h left`;
  const days = Math.floor(hours / 24);
  if (days < 14) return `${days}d ${hours % 24}h left`;
  return `${days}d left`;
}

export function ago(iso: string): string {
  const ms = Date.now() - new Date(iso).getTime();
  if (Number.isNaN(ms)) return '';
  const mins = Math.floor(ms / 60_000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return days === 1 ? 'yesterday' : `${days}d ago`;
}

export function payout(days: number | null): string {
  return days == null ? 'Varies' : `${days} days`;
}
