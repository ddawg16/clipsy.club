import type { SourceAdapter } from '../types.ts';
import { clippingnet } from './clippingnet.ts';
import { direct } from './direct.ts';
import { whop } from './whop.ts';

/**
 * Add a new network by writing one adapter and dropping it in this list.
 *
 * clippingnet is deliberately PARKED — the adapter is written and tested but
 * not wired in, pending the decision about whether to approach them for a
 * partner feed instead of scraping. Re-enable by adding it to this array.
 */
export const adapters: SourceAdapter[] = [whop, direct];

/** Written, not running. See the note above before enabling. */
export const parked: SourceAdapter[] = [clippingnet];

export function enabledAdapters(): SourceAdapter[] {
  return adapters.filter((a) => a.enabled());
}
