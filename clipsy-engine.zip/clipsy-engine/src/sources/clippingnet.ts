import { config } from '../config.ts';
import type { RawCampaign, SourceAdapter } from '../types.ts';
import { safeFetchJson } from '../safety.ts';
import { findCampaignArrays, normalizeCampaign } from './normalize.ts';

/**
 * clipping.net — two-tier adapter.
 *
 *   Tier 1 (preferred): CLIPPINGNET_FEED_URL points at the JSON endpoint the
 *   campaigns page hydrates from. Fast, stable, no browser.
 *
 *   Tier 2 (fallback): render the page with Playwright, capture the JSON that
 *   flies past on the network, and parse the DOM only if nothing usable shows
 *   up. Slower and more brittle — treat it as the backstop, not the plan.
 *
 * Before you point this at production: read their Terms of Service. You are
 * planning to earn team-captain override revenue THROUGH clipping.net, so a
 * scraper that gets your account banned costs you the monetization on day one.
 * Ask them for a partner/affiliate feed first — you are sending them clippers.
 */
export const clippingnet: SourceAdapter = {
  id: 'clippingnet',
  label: 'via clipping.net',

  enabled() {
    return Boolean(config.clippingnet.feedUrl || config.clippingnet.pageUrl);
  },

  async fetchCampaigns(): Promise<RawCampaign[]> {
    if (config.clippingnet.feedUrl) {
      return fetchFromFeed(config.clippingnet.feedUrl);
    }
    return fetchFromBrowser(config.clippingnet.pageUrl);
  },
};

async function fetchFromFeed(url: string): Promise<RawCampaign[]> {
  const headers: Record<string, string> = {
    Accept: 'application/json',
    'User-Agent': config.userAgent,
  };
  if (config.clippingnet.cookie) headers.Cookie = config.clippingnet.cookie;

  const json = await safeFetchJson(url, { headers });
  return toCampaigns(findCampaignArrays(json));
}

async function fetchFromBrowser(pageUrl: string): Promise<RawCampaign[]> {
  const { chromium } = await import('playwright');
  const browser = await chromium.launch({ headless: true });

  try {
    const context = await browser.newContext({ userAgent: config.userAgent });
    if (config.clippingnet.cookie) {
      await context.setExtraHTTPHeaders({ Cookie: config.clippingnet.cookie });
    }
    const page = await context.newPage();

    // Capped: an unbounded capture on a chatty page is an OOM waiting to happen.
    const captured: unknown[] = [];
    const MAX_CAPTURED = 40;
    page.on('response', async (response) => {
      if (captured.length >= MAX_CAPTURED) return;
      const type = response.headers()['content-type'] ?? '';
      if (!type.includes('json')) return;
      try {
        captured.push(await response.json());
      } catch {
        /* non-JSON body behind a JSON content-type; ignore */
      }
    });

    await page.goto(pageUrl, { waitUntil: 'networkidle', timeout: 45_000 });

    // Tier 2a: something in the network traffic looked like a campaign list.
    for (const blob of captured) {
      const arrays = findCampaignArrays(blob);
      if (arrays.length > 0) {
        const found = toCampaigns(arrays);
        if (found.length > 0) return found;
      }
    }

    // Tier 2b: last resort, read the rendered cards.
    // Selectors WILL break when they redesign. Keep them in one place.
    const scraped = await page.$$eval('[data-campaign], article, .campaign-card', (nodes) =>
      nodes.map((n) => {
        const text = (sel: string) => n.querySelector(sel)?.textContent?.trim() ?? '';
        const el = n as HTMLElement;
        return {
          id: el.dataset.campaignId ?? el.getAttribute('id') ?? text('h3') ?? text('h2'),
          name: text('h3') || text('h2') || text('[class*="title"]'),
          rate: text('[class*="rate"]') || text('[class*="cpm"]'),
          min_views: text('[class*="min"]'),
          url: n.querySelector('a')?.getAttribute('href') ?? null,
        };
      }),
    );

    return toCampaigns([scraped.filter((r) => r.name)]);
  } finally {
    await browser.close();
  }
}

function toCampaigns(arrays: Record<string, unknown>[][]): RawCampaign[] {
  const rows = arrays.length > 0 ? arrays[0] : [];
  return rows
    .map((r) => normalizeCampaign('clippingnet', r, { baseUrl: 'https://clipping.net' }))
    .filter((c): c is RawCampaign => c !== null);
}
